# We've Moved!

Material Design Lite v2 has evolved into a new project: [Material Components for the web](https://github.com/material-components/material-components-web).

Please visit us in [our new repository](https://github.com/material-components/material-components-web)!
